<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>MTV Get Fit</title>
    <meta name="keywords"  content="GetFit, Bala Sheety, VJ Bani J, Fitness, Healthy Living" />
    <meta name="title" content="MTV Get Fit - All your Fitness queries answered!">
    <meta name="description" content="Get the body you’ve always dreamed of with 8 Times undefeated National Muay Thai Champ - Bala Shetty and The Fitspiration for millions - VJ Bani J and learn their fitness
secrets! Click Now to Get Fit!">
	<meta property="og:title" content="MTV Get Fit - All your Fitness queries answered!">
	<meta property="og:type" content="website">
	<meta property="og:url" content="http://mtv.in.com/getfit/index.php"/>
	<meta property="og:image" content="http://mtv.in.com/getfit/resources/images/oglogo.jpg">
	<meta property="og:image:type" content="image/png" />
	<meta property="og:description" content="Get the body you’ve always dreamed of with 8 Times undefeated National Muay Thai Champ - Bala Shetty and The Fitspiration for millions - VJ Bani J and learn their fitness
secrets! Click Now to Get Fit!">
	<meta property="fb:app_id" content="1427129764208003" />
	<link rel="stylesheet" type="text/css" href="resources/css/getfit.css?v=4" />
	<style>
	a{text-decoration:none;}
	.introL img{width:40%;}
	.section{
		text-align:center;
	}
	</style>

	<!--[if IE]>
		<script type="text/javascript">
			 var console = { log: function() {} };
		</script>
	<![endif]-->

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
	<script type="text/javascript" src="resources/js/jquery.fullPage.js"></script>
<link rel="stylesheet" type="text/css" href="resources/css/jquery.fancybox.css" media="screen" />
<link rel="stylesheet" type="text/css" href="resources/css/jquery.fancybox-buttons.css" />
<link rel="stylesheet" type="text/css" href="resources/css/jquery.fancybox-thumbs.css" />
<script type="text/javascript" src="resources/js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="resources/js/jquery.fancybox.js"></script>
<script type="text/javascript" src="resources/js/jquery.fancybox-buttons.js"></script>
<script type="text/javascript" src="resources/js/jquery.fancybox-thumbs.js"></script>
<script type="text/javascript" src="resources/js/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="resources/js/jquery.fullPage.js"></script>

<!-- Preloader -->
<script type="text/javascript">
	//<![CDATA[
		$(window).load(function() { // makes sure the whole site is loaded
			$('#status').fadeOut(); // will first fade out the loading animation
			$('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
			$('body').delay(350).css({'overflow':'visible'});
		})
	//]]>
</script>
<script type="text/javascript">
var ar=new Array(33,34,35,36,37,38,39,40);

$(document).keydown(function(e) {
     var key = e.which;
      //console.log(key);
      //if(key==35 || key == 36 || key == 37 || key == 39)
      if($.inArray(key,ar) > -1) {
          e.preventDefault();
          return false;
      }
      return true;
});
</script>

	<script type="text/javascript">
		$(document).ready(function() {

var imgHeight = 160;
var numImgs = 12;
var cont = 1;
var newnew = 0;
    var animation = setInterval(function(){
    var position =  -1 * (cont*imgHeight);
	newnew++;
	if(newnew%5 ==0)
	{
    $('.timer').find('img').css('margin-left', position);
    cont++;
	}
	$(".arrow").effect("bounce", { times: 2 }, 300);
	$('.timer1').html(newnew);
    if(cont == numImgs){
        cont = 0;
    }
    },1000);



                $(".desccontainerinner").hover(function () {
                       $('.become-client').addClass('become-clientnew');
					   $('.btn-hover-label').addClass('btn-hover-labelnew');
					   $('.btn-normal-label').addClass('btn-normal-labelnew');
                },
                function () {
                       $('.become-client').removeClass('become-clientnew');
					   $('.btn-hover-label').removeClass('btn-hover-labelnew');
					   $('.btn-normal-label').removeClass('btn-normal-labelnew');
                });
                $(".desccontainerinner").hover(function () {
                       $('.become-client').addClass('become-clientnew');
					   $('.btn-hover-label').addClass('btn-hover-labelnew');
					   $('.btn-normal-label').addClass('btn-normal-labelnew');
                },
                function () {
                       $('.become-client').removeClass('become-clientnew');
					   $('.btn-hover-label').removeClass('btn-hover-labelnew');
					   $('.btn-normal-label').removeClass('btn-normal-labelnew');
                });

				var numnum = 0;	

			$('#fullpage').fullpage({
				anchors: ['Home', 'episode-1', 'episode-2', 'episode-3', 'episode-4', 'episode-5', 'episode-6', 'episode-7', 'episode-8'],
				navigation: true,
				navigationPosition: 'right',
				scrollingSpeed: 0,
				navigationTooltips: ['Home', 'Healthy Lifestyle', 'Perfect Arms & Legs', 'Eat Healthy', 'Lose 2 inches asap', 'Workout from Home', 'Survive a Street Fight', 'Train for a Marathon', 'Lose 5 kgs in 2 weeks'],
                afterLoad: function (anchorLink, index){
                   if (index == 1) {
				   if(numnum == 0)
				   {
				   $('.intro .intronL').css('opacity','1');
				   $('.intro .intronR').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro .intronL').css('opacity','1');
				   $('.intro .intronR').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $('.intro .intronL').css('opacity','1');
				   $('.intro .intronR').css('opacity','1');
				   $('.intro .intronL').css('top','100%');
				   $('.intro .intronR').css('bottom','100%');
				   $('.intro .intro'+numnum+'L').css('opacity','1');
				   $('.intro .intro'+numnum+'R').css('opacity','1');
				   $('.intro .intro'+numnum+'L').css('top','0%');
				   $('.intro .intro'+numnum+'R').css('bottom','0%');
				   $('.intro .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro .intronL').animate({top:'0%'}, 1000);
				   $('.intro .intronR').animate({bottom:'0%'}, 1000);
				   $('.desccontainer').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $('.intro .intro1nL').css('opacity','1');
				   $('.intro .intro1nR').css('opacity','1');
				   $('.intro .intro1nL').css('top','-100%');
				   $('.intro .intro1nR').css('bottom','-100%');
				   $('.intro .intro'+numnum+'L').css('opacity','1');
				   $('.intro .intro'+numnum+'R').css('opacity','1');
				   $('.intro .intro'+numnum+'L').css('top','0%');
				   $('.intro .intro'+numnum+'R').css('bottom','0%');
				   $('.intro .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro .intronL').animate({top:'0%'}, 1000);
				   $('.intro .intronR').animate({bottom:'0%'}, 1000);
				   $('.desccontainer').delay(1000).fadeIn(1000);
                   }
			       }
                   if (index == 2) {
				   if(numnum == 0)
				   {
				   $('.intro1 .intro1L').css('opacity','1');
				   $('.intro1 .intro1R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro1 .intro1L').css('opacity','1');
				   $('.intro1 .intro1R').css('opacity','1');
				   }
				   else if(numnum == 1)
				   {
				   $("#m1").addClass('activemenu');
		           $("#m1").siblings().removeClass('activemenu');
				   $('.intro1 .intro1L').css('opacity','1');
				   $('.intro1 .intro1R').css('opacity','1');
				   $('.intro1 .intro1L').css('top','-100%');
				   $('.intro1 .intro1R').css('bottom','-100%');
				   $('.intro1 .intronL').css('opacity','1');
				   $('.intro1 .intronR').css('opacity','1');
				   $('.intro1 .intronL').css('top','0%');
				   $('.intro1 .intronR').css('bottom','0%');
				   $('.intro1 .intronL').animate({top:'100%'}, 1000);
				   $('.intro1 .intronR').animate({bottom:'100%'}, 1000);
				   $('.intro1 .intro1L').animate({top:'0%'}, 1000);
				   $('.intro1 .intro1R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer1').delay(1000).fadeIn(1000);
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m1").addClass('activemenu');
		           $("#m1").siblings().removeClass('activemenu');
				   $('.intro1 .intro1L').css('opacity','1');
				   $('.intro1 .intro1R').css('opacity','1');
				   $('.intro1 .intro1L').css('top','100%');
				   $('.intro1 .intro1R').css('bottom','100%');
				   $('.intro1 .intro'+numnum+'L').css('opacity','1');
				   $('.intro1 .intro'+numnum+'R').css('opacity','1');
				   $('.intro1 .intro'+numnum+'L').css('top','0%');
				   $('.intro1 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro1 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro1 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro1 .intro1L').animate({top:'0%'}, 1000);
				   $('.intro1 .intro1R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer1').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m1").addClass('activemenu');
		           $("#m1").siblings().removeClass('activemenu');
				   $('.intro1 .intro1L').css('opacity','1');
				   $('.intro1 .intro1R').css('opacity','1');
				   $('.intro1 .intro1L').css('top','-100%');
				   $('.intro1 .intro1R').css('bottom','-100%');
				   $('.intro1 .intro'+numnum+'L').css('opacity','1');
				   $('.intro1 .intro'+numnum+'R').css('opacity','1');
				   $('.intro1 .intro'+numnum+'L').css('top','0%');
				   $('.intro1 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro1 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro1 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro1 .intro1L').animate({top:'0%'}, 1000);
				   $('.intro1 .intro1R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer1').delay(1000).fadeIn(1000);
                   }
			       }
                   if (index == 3) {
				   if(numnum == 0)
				   {
				   $('.intro2 .intro2L').css('opacity','1');
				   $('.intro2 .intro2R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro2 .intro2L').css('opacity','1');
				   $('.intro2 .intro2R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m2").addClass('activemenu');
		           $("#m2").siblings().removeClass('activemenu');
				   $('.intro2 .intro2L').css('opacity','1');
				   $('.intro2 .intro2R').css('opacity','1');
				   $('.intro2 .intro2L').css('top','100%');
				   $('.intro2 .intro2R').css('bottom','100%');
				   $('.intro2 .intro'+numnum+'L').css('opacity','1');
				   $('.intro2 .intro'+numnum+'R').css('opacity','1');
				   $('.intro2 .intro'+numnum+'L').css('top','0%');
				   $('.intro2 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro2 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro2 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro2 .intro2L').animate({top:'0%'}, 1000);
				   $('.intro2 .intro2R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer2').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m2").addClass('activemenu');
		           $("#m2").siblings().removeClass('activemenu');
				   $('.intro2 .intro2L').css('opacity','1');
				   $('.intro2 .intro2R').css('opacity','1');
				   $('.intro2 .intro2L').css('top','-100%');
				   $('.intro2 .intro2R').css('bottom','-100%');
				   $('.intro2 .intro'+numnum+'L').css('opacity','1');
				   $('.intro2 .intro'+numnum+'R').css('opacity','1');
				   $('.intro2 .intro'+numnum+'L').css('top','0%');
				   $('.intro2 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro2 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro2 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro2 .intro2L').animate({top:'0%'}, 1000);
				   $('.intro2 .intro2R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer2').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 4) {
				   if(numnum == 0)
				   {
				   $('.intro3 .intro3L').css('opacity','1');
				   $('.intro3 .intro3R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro3 .intro3L').css('opacity','1');
				   $('.intro3 .intro3R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m3").addClass('activemenu');
		           $("#m3").siblings().removeClass('activemenu');
				   $('.intro3 .intro3L').css('opacity','1');
				   $('.intro3 .intro3R').css('opacity','1');
				   $('.intro3 .intro3L').css('top','100%');
				   $('.intro3 .intro3R').css('bottom','100%');
				   $('.intro3 .intro'+numnum+'L').css('opacity','1');
				   $('.intro3 .intro'+numnum+'R').css('opacity','1');
				   $('.intro3 .intro'+numnum+'L').css('top','0%');
				   $('.intro3 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro3 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro3 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro3 .intro3L').animate({top:'0%'}, 1000);
				   $('.intro3 .intro3R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer3').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m3").addClass('activemenu');
		           $("#m3").siblings().removeClass('activemenu');
				   $('.intro3 .intro3L').css('opacity','1');
				   $('.intro3 .intro3R').css('opacity','1');
				   $('.intro3 .intro3L').css('top','-100%');
				   $('.intro3 .intro3R').css('bottom','-100%');
				   $('.intro3 .intro'+numnum+'L').css('opacity','1');
				   $('.intro3 .intro'+numnum+'R').css('opacity','1');
				   $('.intro3 .intro'+numnum+'L').css('top','0%');
				   $('.intro3 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro3 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro3 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro3 .intro3L').animate({top:'0%'}, 1000);
				   $('.intro3 .intro3R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer3').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 5) {
				   if(numnum == 0)
				   {
				   $('.intro4 .intro4L').css('opacity','1');
				   $('.intro4 .intro4R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro4 .intro4L').css('opacity','1');
				   $('.intro4 .intro4R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m4").addClass('activemenu');
		           $("#m4").siblings().removeClass('activemenu');
				   $('.intro4 .intro4L').css('opacity','1');
				   $('.intro4 .intro4R').css('opacity','1');
				   $('.intro4 .intro4L').css('top','100%');
				   $('.intro4 .intro4R').css('bottom','100%');
				   $('.intro4 .intro'+numnum+'L').css('opacity','1');
				   $('.intro4 .intro'+numnum+'R').css('opacity','1');
				   $('.intro4 .intro'+numnum+'L').css('top','0%');
				   $('.intro4 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro4 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro4 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro4 .intro4L').animate({top:'0%'}, 1000);
				   $('.intro4 .intro4R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer4').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m4").addClass('activemenu');
		           $("#m4").siblings().removeClass('activemenu');
				   $('.intro4 .intro4L').css('opacity','1');
				   $('.intro4 .intro4R').css('opacity','1');
				   $('.intro4 .intro4L').css('top','-100%');
				   $('.intro4 .intro4R').css('bottom','-100%');
				   $('.intro4 .intro'+numnum+'L').css('opacity','1');
				   $('.intro4 .intro'+numnum+'R').css('opacity','1');
				   $('.intro4 .intro'+numnum+'L').css('top','0%');
				   $('.intro4 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro4 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro4 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro4 .intro4L').animate({top:'0%'}, 1000);
				   $('.intro4 .intro4R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer4').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 6) {
				   if(numnum == 0)
				   {
				   $('.intro5 .intro5L').css('opacity','1');
				   $('.intro5 .intro5R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro5 .intro5L').css('opacity','1');
				   $('.intro5 .intro5R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m5").addClass('activemenu');
		           $("#m5").siblings().removeClass('activemenu');
				   $('.intro5 .intro5L').css('opacity','1');
				   $('.intro5 .intro5R').css('opacity','1');
				   $('.intro5 .intro5L').css('top','100%');
				   $('.intro5 .intro5R').css('bottom','100%');
				   $('.intro5 .intro'+numnum+'L').css('opacity','1');
				   $('.intro5 .intro'+numnum+'R').css('opacity','1');
				   $('.intro5 .intro'+numnum+'L').css('top','0%');
				   $('.intro5 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro5 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro5 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro5 .intro5L').animate({top:'0%'}, 1000);
				   $('.intro5 .intro5R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer5').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m5").addClass('activemenu');
		           $("#m5").siblings().removeClass('activemenu');
				   $('.intro5 .intro5L').css('opacity','1');
				   $('.intro5 .intro5R').css('opacity','1');
				   $('.intro5 .intro5L').css('top','-100%');
				   $('.intro5 .intro5R').css('bottom','-100%');
				   $('.intro5 .intro'+numnum+'L').css('opacity','1');
				   $('.intro5 .intro'+numnum+'R').css('opacity','1');
				   $('.intro5 .intro'+numnum+'L').css('top','0%');
				   $('.intro5 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro5 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro5 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro5 .intro5L').animate({top:'0%'}, 1000);
				   $('.intro5 .intro5R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer5').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 7) {
				   if(numnum == 0)
				   {
				   $('.intro6 .intro6L').css('opacity','1');
				   $('.intro6 .intro6R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro6 .intro6L').css('opacity','1');
				   $('.intro6 .intro6R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m6").addClass('activemenu');
		           $("#m6").siblings().removeClass('activemenu');
				   $('.intro6 .intro6L').css('opacity','1');
				   $('.intro6 .intro6R').css('opacity','1');
				   $('.intro6 .intro6L').css('top','100%');
				   $('.intro6 .intro6R').css('bottom','100%');
				   $('.intro6 .intro'+numnum+'L').css('opacity','1');
				   $('.intro6 .intro'+numnum+'R').css('opacity','1');
				   $('.intro6 .intro'+numnum+'L').css('top','0%');
				   $('.intro6 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro6 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro6 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro6 .intro6L').animate({top:'0%'}, 1000);
				   $('.intro6 .intro6R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer6').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m6").addClass('activemenu');
		           $("#m6").siblings().removeClass('activemenu');
				   $('.intro6 .intro6L').css('opacity','1');
				   $('.intro6 .intro6R').css('opacity','1');
				   $('.intro6 .intro6L').css('top','-100%');
				   $('.intro6 .intro6R').css('bottom','-100%');
				   $('.intro6 .intro'+numnum+'L').css('opacity','1');
				   $('.intro6 .intro'+numnum+'R').css('opacity','1');
				   $('.intro6 .intro'+numnum+'L').css('top','0%');
				   $('.intro6 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro6 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro6 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro6 .intro6L').animate({top:'0%'}, 1000);
				   $('.intro6 .intro6R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer6').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 8) {
				   if(numnum == 0)
				   {
				   $('.intro7 .intro7L').css('opacity','1');
				   $('.intro7 .intro7R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro7 .intro7L').css('opacity','1');
				   $('.intro7 .intro7R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m7").addClass('activemenu');
		           $("#m7").siblings().removeClass('activemenu');
				   $('.intro7 .intro7L').css('opacity','1');
				   $('.intro7 .intro7R').css('opacity','1');
				   $('.intro7 .intro7L').css('top','100%');
				   $('.intro7 .intro7R').css('bottom','100%');
				   $('.intro7 .intro'+numnum+'L').css('opacity','1');
				   $('.intro7 .intro'+numnum+'R').css('opacity','1');
				   $('.intro7 .intro'+numnum+'L').css('top','0%');
				   $('.intro7 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro7 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro7 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro7 .intro7L').animate({top:'0%'}, 1000);
				   $('.intro7 .intro7R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer7').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m7").addClass('activemenu');
		           $("#m7").siblings().removeClass('activemenu');
				   $('.intro7 .intro7L').css('opacity','1');
				   $('.intro7 .intro7R').css('opacity','1');
				   $('.intro7 .intro7L').css('top','-100%');
				   $('.intro7 .intro7R').css('bottom','-100%');
				   $('.intro7 .intro'+numnum+'L').css('opacity','1');
				   $('.intro7 .intro'+numnum+'R').css('opacity','1');
				   $('.intro7 .intro'+numnum+'L').css('top','0%');
				   $('.intro7 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro7 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro7 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro7 .intro7L').animate({top:'0%'}, 1000);
				   $('.intro7 .intro7R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer7').delay(1000).fadeIn(1000);
			       }
			       }
                   if (index == 9) {
				   if(numnum == 0)
				   {
				   $('.intro8 .intro8L').css('opacity','1');
				   $('.intro8 .intro8R').css('opacity','1');
				   }
				   else if (numnum == index)
				   {
				   $('.intro8 .intro8L').css('opacity','1');
				   $('.intro8 .intro8R').css('opacity','1');
				   }
				   else if(numnum > index)
				   {
				   numnum = numnum -1;
				   $("#m8").addClass('activemenu');
		           $("#m8").siblings().removeClass('activemenu');
				   $('.intro8 .intro8L').css('opacity','1');
				   $('.intro8 .intro8R').css('opacity','1');
				   $('.intro8 .intro8L').css('top','100%');
				   $('.intro8 .intro8R').css('bottom','100%');
				   $('.intro8 .intro'+numnum+'L').css('opacity','1');
				   $('.intro8 .intro'+numnum+'R').css('opacity','1');
				   $('.intro8 .intro'+numnum+'L').css('top','0%');
				   $('.intro8 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro8 .intro'+numnum+'L').animate({top:'-100%'}, 1000);
				   $('.intro8 .intro'+numnum+'R').animate({bottom:'-100%'}, 1000);
				   $('.intro8 .intro8L').animate({top:'0%'}, 1000);
				   $('.intro8 .intro8R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer8').delay(1000).fadeIn(1000);
				   }
				   else
				   {
				   numnum = numnum -1;
				   $("#m8").addClass('activemenu');
		           $("#m8").siblings().removeClass('activemenu');
				   $('.intro8 .intro8L').css('opacity','1');
				   $('.intro8 .intro8R').css('opacity','1');
				   $('.intro8 .intro8L').css('top','-100%');
				   $('.intro8 .intro8R').css('bottom','-100%');
				   $('.intro8 .intro'+numnum+'L').css('opacity','1');
				   $('.intro8 .intro'+numnum+'R').css('opacity','1');
				   $('.intro8 .intro'+numnum+'L').css('top','0%');
				   $('.intro8 .intro'+numnum+'R').css('bottom','0%');
				   $('.intro8 .intro'+numnum+'L').animate({top:'100%'}, 1000);
				   $('.intro8 .intro'+numnum+'R').animate({bottom:'100%'}, 1000);
				   $('.intro8 .intro8L').animate({top:'0%'}, 1000);
				   $('.intro8 .intro8R').animate({bottom:'0%'}, 1000);
				   $('.desccontainer8').delay(1000).fadeIn(1000);
			       }
			       }
                },
				onLeave: function(index, direction){
                   if (index == 1) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer').fadeOut();
			       }
                   if (index == 2) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer1').fadeOut();
			       }
                   if (index == 3) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer2').fadeOut();
			       }
                   if (index == 4) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer3').fadeOut();
			       }
                   if (index == 5) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer4').fadeOut();
			       }
                   if (index == 6) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer5').fadeOut();
			       }
                   if (index == 7) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer6').fadeOut();
			       }
                   if (index == 8) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer7').fadeOut();
			       }
                   if (index == 9) {
				    numnum = index;
				   $('.intronL').css('opacity','0');
				   $('.intronR').css('opacity','0');
				   $('.intro1L').css('opacity','0');
				   $('.intro1R').css('opacity','0');
				   $('.intro2L').css('opacity','0');
				   $('.intro2R').css('opacity','0');
				   $('.intro3L').css('opacity','0');
				   $('.intro3R').css('opacity','0');
				   $('.intro4L').css('opacity','0');
				   $('.intro4R').css('opacity','0');
				   $('.intro5L').css('opacity','0');
				   $('.intro5R').css('opacity','0');
				   $('.intro6L').css('opacity','0');
				   $('.intro6R').css('opacity','0');
				   $('.intro7L').css('opacity','0');
				   $('.intro7R').css('opacity','0');
				   $('.intro8L').css('opacity','0');
				   $('.intro8R').css('opacity','0');
				   $('.desccontainer8').fadeOut();
			       }
                }
			});
		});
		
	</script>
	<script type="text/javascript">
        $(document).ready(function() {
		console.log(window.location.href.split('-').length);
            if(window.location.href.split('-').length > 1){
                if(1){
					var c=window.location.href;
					var sv = c.split('-');
					var mid = sv[sv.length-2];
					var dd = mid.split('.');
					console.log(dd[0]);
                    $(".epiCont").append('<a id="'+mid+'" data-fancybox-type="iframe" class="openEpisode" href="iframeEpisode.php?id='+mid+'"></a>')
                    $('#'+dd[0]).fancybox({type:'iframe',overlayShow:true}).trigger('click');
                }else{
                    $('#'+dd[0]).fancybox({type:'iframe',overlayShow:true}).trigger('click');
                }

            }
		 $(".fancybox").click(function(){
                //window.location.href=$(this).attr("href");
				window.parent.history.replaceState( {} , window.location.href,$(this).attr("name") );
            });

        $('.fancybox').fancybox();

        });
	</script>
    <style>
body {
	overflow: hidden;
}

/* Preloader 123*/

#preloader {
    position:fixed;
    top:0;
    left:0;
    right:0;
    bottom:0;
    background-color:#262626; /* change if the mask should have another color then white */
    z-index:9999; /* makes sure it stays on top */
}

#status {
    width:200px;
    height:200px;
    position:absolute;
    left:50%; /* centers the loading animation horizontally one the screen */
    top:50%; /* centers the loading animation vertically one the screen */
    background-image:url(resources/images/status.gif); /* path to your loading animation */
    background-repeat:no-repeat;
    background-position:center;
    margin:-100px 0 0 -100px; /* is width and height divided by two */
}
	</style>
</head>
<body>
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<div id="fullpage">

	<div class="socialcont">
          <div class="social fl">
              <a href="http://mtv.in.com/" target="_blank"><div class="mtv fl"></div></a>
              <a href="https://www.facebook.com/mtvindia" target="_blank"><div class="face fl"></div></a>
              <a href="https://twitter.com/mtvindia" target="_blank"><div class="twit fl"></div></a>
				<div class="clear"></div>
		  </div>
          <div class="timer fl">
		        <img src="resources/images/timer.png" class="fl" alt="">
				<div class="timer1">0</div>
				<div class="timer2">calories burnt</div>
		  </div>
		  <div class="clear"></div>
    </div>

	<div class="section " id="section0">
		<div class="intro">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="arrow" style="z-index:9999;"><a href="#episode-1" style="display:block;"><div id="arrow" style="height:50px;width:50px;margin:0px auto;"><img src="resources/images/arrow.png"/></div></a></div>
		</div>
	</div>
	<div class="section" id="section1">
		<div class="intro1">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section2">
		<div class="intro2">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section3">
		<div class="intro3">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section4">
		<div class="intro4">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section5">
		<div class="intro5">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section6">
		<div class="intro6">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section7">
		<div class="intro7">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>
	<div class="section" id="section8">
		<div class="intro8">
			 <div class="intronR">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="rfull"></div>
			 </div>
		     <div class="intronL">
			      <div style="background-image:url(resources/images/intronew.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro1R">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro1L">
			      <div style="background-image:url(resources/images/ep1-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro2R">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro2L">
			      <div style="background-image:url(resources/images/ep2-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro3R">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro3L">
			      <div style="background-image:url(resources/images/ep3-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro4R">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro4L">
			      <div style="background-image:url(resources/images/ep4-bani.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro5R">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro5L">
			      <div style="background-image:url(resources/images/ep5-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro6R">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro6L">
			      <div style="background-image:url(resources/images/ep6-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro7R">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro7L">
			      <div style="background-image:url(resources/images/ep7-bala.jpg)" class="lfull"></div>
			 </div>
			 <div class="intro8R">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="rfull"></div>
			 </div>
		     <div class="intro8L">
			      <div style="background-image:url(resources/images/ep8-bala.jpg)" class="lfull"></div>
			 </div>
		</div>
	</div>

</div>
             <div class="desccontainer1">			     
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208728" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-healthy-habits-iframe-100208728.html#episode-1" href="iframeEpisode.php?id=100208728">Healthy Lifestyle</a></div>
				  <div class="descmain"><a id="100208728" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-healthy-habits-iframe-100208728.html#episode-1" href="iframeEpisode.php?id=100208728">Want to Get Fit? Start with getting a healthy lifestyle!<br>Watch & learn as Bani J gives out her 5 healthy habits.</a></div>
				  <div class="buttonmain">
				  	<a class="btn become-client fancybox fancybox.iframe" id="100208728" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-healthy-habits-iframe-100208728.html#episode-1" href="iframeEpisode.php?id=100208728" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>

             <div class="desccontainer2">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208729" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-perfect-arms-legs-iframe-100208729.html#episode-2" href="iframeEpisode.php?id=100208729">Perfect Arms & Legs</a></div>
				  <div class="descmain"><a id="100208729" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-perfect-arms-legs-iframe-100208729.html#episode-2" href="iframeEpisode.php?id=100208729">Your perfect body isn't too far off. Bani J lets you in on her workout regime to help you get the perfect arms & legs!</a></div>
				  <div class="buttonmain">
				  	<a class="btn become-client fancybox fancybox.iframe" id="100208729" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-perfect-arms-legs-iframe-100208729.html#episode-2" href="iframeEpisode.php?id=100208729" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>

			 </div>
             <div class="desccontainer3">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208730" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-eat-healthy-iframe-100208730.html#episode-3" href="iframeEpisode.php?id=100208730">Eat Healthy</a></div>
				  <div class="descmain"><a id="100208730" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-eat-healthy-iframe-100208730.html#episode-3" href="iframeEpisode.php?id=100208730">You are what you eat! Bani J shares 2 of her favourite healthy recipes.<br>Try them and Get Fit!</a></div>
				  <div class="buttonmain">
				  	<a class="btn become-client fancybox fancybox.iframe" id="100208730" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-eat-healthy-iframe-100208730.html#episode-3" href="iframeEpisode.php?id=100208730" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>

			 </div>
             <div class="desccontainer4">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208731" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-lose-2-inches-asap-iframe-100208731.html#episode-4" href="iframeEpisode.php?id=100208731">Lose 2 inches asap</a></div>
				  <div class="descmain"><a id="100208731" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-lose-2-inches-asap-iframe-100208731.html#episode-4" href="iframeEpisode.php?id=100208731">Want to slim down for your best friend's wedding or the upcoming beach vacation? Here are some quick slimming tips from Bani J!</a></div>
				  <div class="buttonmain">
				  	<a class="btn become-client fancybox fancybox.iframe" id="100208731" name="http://mtv.in.com/getfit/mtv-get-fit-with-bani-lose-2-inches-asap-iframe-100208731.html#episode-4" href="iframeEpisode.php?id=100208731" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>
             <div class="desccontainer5">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208732" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-workout-from-home-iframe-100208732.html#episode-5" href="iframeEpisode.php?id=100208732">Workout from Home</a></div>
				  <div class="descmain"><a id="100208732" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-workout-from-home-iframe-100208732.html#episode-5" href="iframeEpisode.php?id=100208732">Too busy to visit the gym? Muay Thai Champ Bala shows you how to get fit in just 9 minutes everyday!</a></div>
				  <div class="buttonmain">
                      <a class="btn become-client fancybox fancybox.iframe" id="100208732" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-workout-from-home-iframe-100208732.html#episode-5" href="iframeEpisode.php?id=100208732" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>
             <div class="desccontainer6">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208733" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-survive-a-street-fight-iframe-100208733.html#episode-6" href="iframeEpisode.php?id=100208733">Survive a Street Fight</a></div>
				  <div class="descmain"><a id="100208733" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit-get-fit-with-bala-survive-a-street-fight-iframe-100208733.html#episode-6" href="iframeEpisode.php?id=100208733">Street fights are extremely lethal but here are some self-defense techniques that will help you escape in emergencies.</a></div>
				  <div class="buttonmain">
                      <a class="btn become-client fancybox fancybox.iframe" id="100208733" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-survive-a-street-fight-iframe-100208733.html#episode-6" href="iframeEpisode.php?id=100208733" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>
             <div class="desccontainer7">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208734" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-train-for-a-marathon-iframe-100208734.html#episode-7" href="iframeEpisode.php?id=100208734">Train for a Marathon</a></div>
				  <div class="descmain"><a id="100208734" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-train-for-a-marathon-iframe-100208734.html#episode-7" href="iframeEpisode.php?id=100208734">Dream runs are for amateurs. Muay Thai champion Bala shows how you can train to run a full marathon!</a></div>
				  <div class="buttonmain">
                      <a class="btn become-client fancybox fancybox.iframe" id="100208734" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-train-for-a-marathon-iframe-100208734.html#episode-7" href="iframeEpisode.php?id=100208734" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>
             <div class="desccontainer8">
			      <div class="desccontainerinner">
				  <div class="deschead"><a id="100208735" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-lose-5-kgs-in-2-weeks-iframe-100208735.html#episode-8" href="iframeEpisode.php?id=100208735">Lose 5 kgs in 2 weeks</a></div>
				  <div class="descmain"><a id="100208735" class="fancybox fancybox.iframe" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-lose-5-kgs-in-2-weeks-iframe-100208735.html#episode-8" href="iframeEpisode.php?id=100208735">Determined to shed those pesky extra kilos?<br>Here are some hardcore tips to get you going!</a></div>
				  <div class="buttonmain">
                      <a class="btn become-client fancybox fancybox.iframe" id="100208735" name="http://mtv.in.com/getfit/mtv-get-fit-with-bala-lose-5-kgs-in-2-weeks-iframe-100208735.html#episode-8" href="iframeEpisode.php?id=100208735" style="width:220px;">
		                 <span class="btn-normal-label" style="width:125px;">WATCH NOW</span>
		                 <span class="btn-hover-label" style="width:145px;">WATCH NOW</span>
	                </a>
                  </div>
				  </div>
			 </div>

<!-- google-analytics START -->
<script type='text/javascript' >
    var _gaq = _gaq || [];

    _gaq.push(['_setAccount', 'UA-16752562-1']);

    _gaq.push(['_setDomainName', 'mtv.in.com']);

    _gaq.push(['_trackPageview']);



    (function() {

        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

        ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';

        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

    })();

</script>
<!-- google-analytics END -->

</body>
</html>